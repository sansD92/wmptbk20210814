<section style="background-color: #8C1824" class="counter_wrap background_bg fixed_bg " >
    <div class="container">
        <div class="row align-items-center justify-content-center">
        	<div class="col-md-5 text_white text-center text-md-left mb-4 mb-md-0 " >
            	<div class="heading_s1 heading_light text-center text-md-left">
                	<h2>Highlight</h2>
                </div>
                <h3>Join With PT Widodo Makmur Perkasa, Tbk</h3>
                <a href="https://www.jobstreet.co.id/en/companies/775340-pt-widodo-makmur-perkasa" target="_blank" class="btn btn-outline-white">Join</a>
            </div>
        	<div class="col-lg-6 offset-lg-1 col-md-7 col-sm-12 col-11 ">
            	<div class="row overflow_hide">
                	<div class="col-6 couter_border">
                        <div class="box_counter text-center">
                            <img src="<?php echo base_url()?>assets/frontend/campur/icon1.png">
                            <h3 class="counter_text"><span class="counter">5</span></h3>
                            <h3>Business Line</h3>
                        </div>
                    </div>
                    <div class="col-6 couter_border">
                        <div class="box_counter text-center">
                            <img src="<?php echo base_url()?>assets/frontend/campur/icon3.png">
                            <h3 class="counter_text"><span class="counter">26</span></h3>
                            <h3>Operating Year</h3>
                        </div>
                    </div>
                    <div class="col-6 couter_border">
                        <div class="box_counter text-center">
                            <img src="<?php echo base_url()?>assets/frontend/campur/icon4.png">
                            <h3 class="counter_text"><span class="counter">1.456</span>+</h3>
                            <h3>Human Resources In Indonesia</h3>
                        </div>
                    </div>
                    <div class="col-6 couter_border">
                        <div class="box_counter text-center">
                            <img src="<?php echo base_url()?>assets/frontend/campur/icon5.png">
                            <h3 class="counter_text"><span class="counter">550</span></h3>
                            <h3>Product Items</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
