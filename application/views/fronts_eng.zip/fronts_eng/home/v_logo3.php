<section>
	<div class="container">
    	<div class="row">
        	<div class="col-md-12 responsive">
            <img src="<?php echo base_url()?>assets/frontend/campur/logoallwmp.jpg" alt="image">
            </div>
        </div>
    </div>
</section>
