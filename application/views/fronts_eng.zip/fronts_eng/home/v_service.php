<section class="small_pb">
	<div class="container">
    	<div class="row">
        	<div class="col-md-12">
                <div class="heading_s4 text-center">
                	<span class="sub_title">AKTIVITAS BISNIS</span>
                    <h2>AKTIVITAS BISNIS</h2>
                </div>
                <!-- <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim.<br class="d-none d-sm-block"> Nullam id varius nunc id varius nunc.</p> -->
            </div>
        </div>
        <div class="row " >
        	<div class="col-md-4 mt-3 mt-md-4">
            	<div class="flip_box text_white">
					<div class="front background_bg overlay_bg2" data-img-src="<?php echo base_url()?>assets/frontend/intibisnis/peternakan-sapi.jpg">
						<div class="inner">
							<h5>Peternakan Sapi</h5>

						</div>
					</div>
					<div class="back bg_blue">
						<div class="inner">
                          <h5>Peternakan Sapi</h5>
													<ul>
														<ol>Total Kapasitas</ol>
														<ol>172.000 ekor</ol>
														<ol>4 farm</ol>
														<ol>140 hektar</ol>
														<ol>15% national market share</ol>
													</ul>
													<a href="<?php echo base_url()?>produk1" class="btn btn-outline-white">Selengkapnya</a>
						</div>
					</div>
				</div>
            </div>
            <div class="col-md-4 mt-3 mt-md-4">
            	<div class="flip_box text_white">
					<div class="front background_bg overlay_bg2" data-img-src="<?php echo base_url()?>assets/frontend/intibisnis/rphcam.jpg">
						<div class="inner">
							<h5>Rumah Potong Hewan</h5>
						</div>
					</div>
					<div class="back bg_blue">
						<div class="inner">
              <h5>Rumah Potong Hewan</h5>
							<ul>
								<ol>300 ekor/hari</ol>
								<ol>warehouse 300 ton</ol>
								<ol>chiller & cold storage 500 ton</ol>
								<ol>52 ton blast freezer</ol>
								<ol>sertivikasi NKV & halal MUI</ol>
							</ul>
							<a href="<?php echo base_url()?>produk2" class="btn btn-outline-white">Selengkapnya</a>
						</div>
					</div>
				</div>
            </div>
            <div class="col-md-4 mt-3 mt-md-4">
            	<div class="flip_box text_white">
					<div class="front background_bg overlay_bg2" data-img-src="<?php echo base_url()?>assets/frontend/intibisnis/rpa2.jpg">
						<div class="inner">
							<h5>Rumah Potong Ayam</h5>
						</div>
					</div>
					<div class="back bg_blue">
						<div class="inner">
                          <h5>Rumah Potong Ayam</h5>
													<ul>
														<ol>24.000 ekor/jam</ol>
														<ol>storage</ol>
														<ol>blast</ol>
														<ol>freezer</ol>
													</ul>
													<a href="<?php echo base_url()?>produk5" class="btn btn-outline-white">Selengkapnya</a>
						</div>
					</div>
				</div>
            </div>
           <div class="col-md-4 mt-3 mt-md-4">
            	<div class="flip_box text_white">
					<div class="front background_bg overlay_bg2" data-img-src="<?php echo base_url()?>assets/frontend/intibisnis/pwm.jpg">
						<div class="inner">
							<h5>Produksi Olahan</h5>
						</div>
					</div>
					<div class="back bg_blue">
						<div class="inner">
                          <h5>Produksi Olahan</h5>
													<ul>
														<ol>produksi sosis</ol>
														<ol>nugget</ol>
														<ol>patty </ol>
														<ol>bakso</ol>
														<ol>minipao </ol>
														<ol>dendeng</ol>
													</ul>
													<a href="<?php echo base_url()?>produk3" class="btn btn-outline-white">Selengkapnya</a>
						</div>
					</div>
				</div>
            </div>
           <div class="col-md-4 mt-3 mt-md-4">
            	<div class="flip_box text_white">
					<div class="front background_bg overlay_bg2" data-img-src="<?php echo base_url()?>assets/frontend/intibisnis/feedmill.jpg">
						<div class="inner">
							<h5>Pemprosesan  Beras</h5>
						</div>
					</div>
					<div class="back bg_blue">
						<div class="inner">
                          <h5>Pemprosesan  Beras</h5>
													<ul>
														<ol>50.000 ton</ol>
													</ul>
						 <a href="<?php echo base_url()?>produk6" class="btn btn-outline-white">Selengkapnya</a>
						</div>
					</div>
				</div>
            </div>
            <div class="col-md-4 mt-3 mt-md-4">
            	<div class="flip_box text_white">
					<div class="front background_bg overlay_bg2" data-img-src="<?php echo base_url()?>assets/frontend/intibisnis/gmp.jpg">
						<div class="inner">
							<h5>Penyamakan Kulit</h5>
						</div>
					</div>
					<div class="back bg_blue">
						<div class="inner">
                          <h5>PABRIK KULIT</h5>
													<ul>
														<ol>lembar kulit</ol>
													</ul>
							<a href="<?php echo base_url()?>produk4" class="btn btn-outline-white">Selengkapnya</a>
						</div>
					</div>
				</div>
            </div>
        </div>
    </div>
</section>
