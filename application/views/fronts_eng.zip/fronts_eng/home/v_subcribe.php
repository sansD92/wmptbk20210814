<section style="background-color: #006669"class="small_pt small_pb bg_blue">
	<div class="container">
    	<div class="row">
        	<div class="col-md-12 text_white text-center">
            	<div class="">
                    <h2 class="">Get the Latest Information PT Widodo Makmur Perkasa, Tbk</h2>
                    <p>For those of you who are subscribed, we send the latest information via Email</p>
                    <div class="newsletter_form newslattter_small">
                        <form>
                            <input class="form-control" type="text" required="" placeholder="Email Address">
                            <button type="submit" title="Subscribe" class="btn btn-default" name="submit" style="background-color: #088282; border-color:#006669 ;" value="Submit">
                            	Subscribe
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
