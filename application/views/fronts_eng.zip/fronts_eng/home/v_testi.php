<section class="counter_wrap background_bg fixed_bg overlay_bg2" data-img-src="<?php echo base_url()?>assets/frontend/sawah.jpeg">
	<div class="container">
    	<div class="row">
        	<div class="col-md-12">
            	<div class="heading_s4 text-center">
                	<span style="color: #fff"class="sub_title">Quotes</span>
                	<h2 style="color: #fff">WMP</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
        	<div class="col-md-8 " >
            	<div class="testimonial_slider testimonial_style3 carousel_slide1 owl-carousel owl-theme" data-autoheight="true" data-loop="true" data-autoplay="true">
                	<div class="item">
                    	<div class="testimonial_box">
                        		<div class="testimonial_img">
                            	<img class="rounded-circle m-auto" src="<?php echo base_url()?>assets/frontend/qoutes/1.jpg"/>
                            </div>
                            <div class="testi_meta">
                                <h6 style="color: #fff">TUMIYANA</h6>
                                <span style="color: #fff"> Chief Excecutive Officer Widodo Makmur Perkasa</span>
                            	<p style="color: #fff">
																Keberhasilan sebuah business ditentukan oleh INOVASI dan kecepatan memasuki pasar</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
